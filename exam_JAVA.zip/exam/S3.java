package exam;

import java.util.Arrays;
import java.util.Scanner;

//첫줄에 숫자의 총개수 N이 입력
//2줄에 N개의 숫자가 랜덤하게 입력
//오름차순 정렬해서 화면에 표시
//입력: 5
//    5 2 3 4 1
//출력:1 2 3 4 5   
public class S3 {
	public static void main(String[] args) {
//		Scanner 입력 받기
		Scanner scanner=new Scanner(System.in);
//		숫자 개수 N 입력 받기
		int N=scanner.nextInt();
		
//		수업중 배운 배열로 하려고 하는데 어렵네요..
//		숫자를 글자로 바꾼 배열 // 안되긴합니다
//		>>int[]값이 필요한거 같은데 모르겠습니다
//		String[] str=Arrays.stream(N)
//				.mapToObj(x ->String.valueOf(x))
//				.toArray(x->new String[x]);
//		Arrays.stream(str).forEach(x->System.out.println(x));
	
//		인터넷 참조 코딩2
		String input=scanner.next();
		char[] digits=input.toCharArray();
		
		Arrays.sort(digits); // 오름차순 정렬
		
		System.out.println(new String(digits));
		scanner.close();
	}
}
