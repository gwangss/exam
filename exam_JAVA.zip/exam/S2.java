package exam;

public class S2 {
	public static void main(String[] args) {
		int a=19;
		if(a>=19) {
			System.out.println("성인");
		} else {
			System.out.println("미성년자");
		}
	}
}
